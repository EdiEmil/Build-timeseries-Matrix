# PhoenixPodman

## Setup

### Windows one-time setup
If you are using Linux, skip this section.

Make sure you have WSL installed. You probably need to raise a ticket to have it installed.

Update WSL to latest version:
```powershell
> wsl --update
```

Make sure WSL2 is used as the default WSL version:
```powershell
> wsl --set-default-version 2
```

Install Ubuntu:
```powershell
> wsl --install -d Ubuntu
```
Follow the instructions to install Ubuntu and set up a user.

If you already have a Ubuntu distribution installed, make sure it is using version 2:
```powershell
> wsl -l -v
```
The version column should show `2` for the Ubuntu distribution.

If it's showing `1`, convert it to version 2:
```powershell
> wsl --set-version Ubuntu 2
```

Start WSL to obtain a shell:
```powershell
> wsl
```

Edit the WSL configuration:
```bash
$ sudo vi /etc/wsl.conf
```

and make sure the file contains the following lines (disables the windows PATH integration feature):

```
[boot]
systemd=true

[interop]
enable = false
appendWindowsPath = false
```

### Install podman as docker alias
```bash
$ sudo apt update
$ sudo apt install -y podman
$ echo "alias docker=podman" >> ~/.bash_aliases
```

### Install podman-compose as docker-compose alias
```bash
$ sudo apt install -y python3-pip
$ pip3 install --user podman-compose
$ echo "export PATH=\$PATH:/home/$USER/.local/bin" >> ~/.bashrc
$ echo "alias docker-compose=podman-compose" >> ~/.bash_aliases
```

### Install dbus-user-session for WSL
You can skip this if you are not using WSL.
If you miss this packages, ports will hang open on rootlessport as described here https://github.com/containers/podman/issues/9447
```bash
$ sudo apt install dbus-user-session
```

### Restart WSL
Exit the shell and restart WSL:
```powershell
> wsl --shutdown
```

Open a new shell and continue with the setup.
```powershell
> wsl
```

### Test if everything is fine
```bash
$ podman run hello-world
```

you should see an output similar to this:
```bash
Resolved "hello-world" as an alias (/etc/containers/registries.conf.d/shortnames.conf)
Trying to pull docker.io/library/hello-world:latest...
Getting image source signatures
Copying blob c1ec31eb5944 done
Copying config d2c94e258d done
Writing manifest to image destination
Storing signatures

Hello from Docker!
This message shows that your installation appears to be working correctly.

To generate this message, Docker took the following steps:
 1. The Docker client contacted the Docker daemon.
 2. The Docker daemon pulled the "hello-world" image from the Docker Hub.
    (amd64)
 3. The Docker daemon created a new container from that image which runs the
    executable that produces the output you are currently reading.
 4. The Docker daemon streamed that output to the Docker client, which sent it
    to your terminal.

To try something more ambitious, you can run an Ubuntu container with:
 $ docker run -it ubuntu bash

Share images, automate workflows, and more with a free Docker ID:
 https://hub.docker.com/

For more examples and ideas, visit:
 https://docs.docker.com/get-started/
```

### Build PhoenixCommon and install to local Maven repo
```bash
$ git clone git@int.gitlab.ihsmarkit.com:clarifi/PhoenixCommon.git
$ cd PhoenixCommon
$ git checkout threadly_7_0
$ ./gradlew publishToMavenLocal
```

### Build PhoenixConf and install to local Maven repo
```bash
$ git clone git@int.gitlab.ihsmarkit.com:clarifi/PhoenixConf.git
$ cd PhoenixConf
$ ./gradlew publishToMavenLocal
```

## Build the service container images
```bash
$ ./gradlew build buildContainerImages
```

## Start the services
```bash
$ podman-compose -f src/main/docker-compose/core/docker-compose.yml up -d
```
This will start 3 containers, 2 nodes and 1 api server (serving on port 8087).

You can see the containers running using the following command:

```bash
$ podman ps
CONTAINER ID  IMAGE                          COMMAND     CREATED        STATUS            PORTS                   NAMES
d8238c342b5c  localhost/phoenix-api:latest               3 minutes ago  Up 3 minutes ago  0.0.0.0:8087->8081/tcp  phoenix-api
c19c8f857f6d  localhost/phoenix-node:latest              3 minutes ago  Up 3 minutes ago                          phoenix-node-1
f7a148576bf8  localhost/phoenix-node:latest              3 minutes ago  Up 3 minutes ago                          phoenix-node-2
```

You can inspect the logs using `podman logs <container-id>` where `<container-id>` can also be the container name (e.g. `podman logs phoenix-api`). You can tail the log by using the -f or --follow flag.

## Stop the services
```bash
$ podman-compose -f src/main/docker-compose/core/docker-compose.yml down
```