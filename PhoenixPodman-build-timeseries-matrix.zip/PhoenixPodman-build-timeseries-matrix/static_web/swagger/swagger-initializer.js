window.onload = function() {
  //<editor-fold desc="Changeable Configuration Block">



  // Initialize Swagger UI with your custom configuration
  window.ui = SwaggerUIBundle({
    url: "openapi.json", // Point to your Swagger JSON file in the same directory as index.html
    dom_id: '#swagger-ui',
    deepLinking: true,
    presets: [
      SwaggerUIBundle.presets.apis,
      SwaggerUIStandalonePreset
    ],
    plugins: [
      SwaggerUIBundle.plugins.DownloadUrl
    ],
    layout: "StandaloneLayout"
  });

  //</editor-fold>
};

