package com.clarifi.phoenix.apiserver;

import com.clarifi.config.Configurator;
import com.clarifi.config.ConfiguratorBuilder;
import com.clarifi.config.Fields;
import com.clarifi.config.Property;
import com.clarifi.config.sources.JavaUtilPropertySource;
import io.undertow.Undertow;
import io.undertow.UndertowOptions;

public class Server
{
  @Property("app.port")
  public static final int DEFAULT_PORT = Fields.anInt();
  @Property("app.host")
  public static final String DEFAULT_HOST = Fields.aString();

  public static void main( String[] args ) {
      Configurator conf = new ConfiguratorBuilder()
              .addSource(JavaUtilPropertySource.from(Server.class.getClassLoader().getResourceAsStream("defaults.properties")))
              .build();
      conf.configure(Server.class);

    // Once again pull in a bunch of common middleware.
    Undertow.Builder undertow = Undertow.builder()
      //This setting is needed if you want to allow '=' as a value in a cookie.
      //If you base64 encode any cookie values you probably want it on.
      .setServerOption( UndertowOptions.ALLOW_EQUALS_IN_COOKIE_VALUE, true )
      // Needed to set request time in access logs
      .setServerOption( UndertowOptions.RECORD_REQUEST_START_TIME, true )
      .addHttpListener( DEFAULT_PORT, DEFAULT_HOST, Router.ROUTER );

      undertow.build().start();
  }
}
