package com.phoenix.repl;

import com.amazon.ion.IonReader;
import com.amazon.ion.IonSystem;
import com.amazon.ion.Timestamp;
import com.amazon.ion.system.IonSystemBuilder;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;


public class ClientRequestServlet extends HttpServlet {

    static Map<Integer, CommandAction> cache = new ConcurrentHashMap<>();
    static Map<Integer, Thread> transactionThreadMap = new ConcurrentHashMap<>();
    static Map<String, CommandInterface> registry = new ConcurrentHashMap<>();

    static byte [] registeredCommands;
    static final int ID = 1000;
    static final int responseWaitTime = 2000;
    private ScheduledExecutorService scheduler;
    private CommandRegistry commandRegistry;

    @Override
    public void init() throws ServletException {
        // Initialize the scheduler with a thread pool of size 1
        scheduler = Executors.newScheduledThreadPool(1);
        // Schedule the method to run periodically
        scheduler.scheduleAtFixedRate(this::periodicMethod, 0, 60, TimeUnit.SECONDS);

        //populate registry
        commandRegistry = new CommandRegistry();
        registry = commandRegistry.getRegistryMap();
        registeredCommands = commandRegistry.getRegisteredCommands();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Handle the GET request here
        response.setContentType("text/html");
        response.getWriter().write("<h1>Hello, this is the response for the GET request!</h1>");
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        try {
            IonReader ionReader = getCommandReader(request);
            String commandName = null;
            if(ionReader.next() != null)
              commandName = ionReader.stringValue();

            CommandAction result = null;

            if("status".equals(commandName)){
                CommandInterface commandInterface = registry.get("status").decodeCommand(ionReader, 0);
                int transactionId = commandInterface.getTransactionId();

                if(cache.containsKey(transactionId))
                    result = cache.get(transactionId);
                else{
                    commandInterface.execute();

                    result = new CommandAction(transactionId,commandInterface,"fail", null);
                }
            }
            else if("init".equals(commandName)){
                response.setHeader("Content-Encoding", "gzip");

                response.setHeader("Content-Length", String.valueOf(registeredCommands.length));

                // Set the content type to indicate that it's gzipped data
                response.setContentType("application/octet-stream");

                // Write the gzipped data to the response output stream
                response.getOutputStream().write(registeredCommands);
                return;
            }
            else if("cancel".equals(commandName)){

                CommandInterface commandInterface = registry.get("cancel").decodeCommand(ionReader, 0);
                int transactionId = commandInterface.getTransactionId();
                if(!transactionThreadMap.isEmpty() && transactionThreadMap.containsKey(transactionId)){
                    commandInterface.execute();

                    result = new CommandAction(transactionId, commandInterface,"terminated", null);
                    transactionThreadMap.remove(transactionId);
                }else
                    result = new CommandAction(transactionId, new NoOpCommand("No record of transaction Id:"+transactionId), "fail", null);
                cache.remove(transactionId);
            }

            else{
                int transactionId = gen();
                CommandInterface commandInterface = null;
                if(registry.containsKey(commandName.toLowerCase())){
                    commandInterface = registry.get(commandName.toLowerCase()).decodeCommand(ionReader,transactionId);
                }
                else
                    commandInterface = new NoOpCommand("Invalid operation");

                ionReader.close();
                CommandRunnable commandRunnable = new CommandRunnable(transactionId,commandInterface);
                Thread thread = new Thread(commandRunnable);
                thread.start();
                transactionThreadMap.put(transactionId, thread);

                if(!cache.containsKey(transactionId)){
                    int timer = 0;
                    // check after every 250ms if the job has completed till 2 seconds
                    do{
                        Thread.sleep(250);
                        if(cache.containsKey(transactionId)) {
                            result = cache.get(transactionId);
                            break;
                        }
                        timer += 250;
                    }while(timer < responseWaitTime);

                    if(!cache.containsKey(transactionId)){
                        String desc = "The operation has completed 20%, Please use the transaction Id ("+transactionId+") " +
                                "to check the status of transaction in few seconds after";
                        CommandInterface commandInterface1 = new NoOpCommand(desc);

                        result = new CommandAction(transactionId, commandInterface1, "inProgress", Timestamp.now());
                        cache.put(transactionId, result);
                    }

                }
            }

            byte [] gzippedIonFormatCmdResult = CommandAction.convertToZippedByteArray(result);

            response.setHeader("Content-Encoding", "gzip");
            response.setHeader("Content-Length", String.valueOf(gzippedIonFormatCmdResult.length));

            // Set the content type to indicate that it's gzipped data
            response.setContentType("application/octet-stream");

            // Write the gzipped data to the response output stream
            response.getOutputStream().write(gzippedIonFormatCmdResult);
        } catch (Exception e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            e.printStackTrace();
        }
    }

    IonReader getCommandReader(HttpServletRequest request) throws IOException {
        InputStream inputStream = request.getInputStream();


        IonSystem ionSystem = IonSystemBuilder.standard().build();
        IonReader ionReader = ionSystem.newReader(inputStream);

        ionReader.next(); // Start reading the struct
        ionReader.stepIn();

        return ionReader;
    }

    class CommandRunnable implements Runnable{

        int transactionId;
        CommandInterface commandInterface;
        CommandRunnable(int transactionId, CommandInterface commandInterface){
            this.transactionId = transactionId;
            this.commandInterface = commandInterface;
        }
        @Override
        public void run() {

            String status = "";
            try{
                    commandInterface.execute();
                    status = "success";

            }catch (Exception e){
                CharArrayWriter cw = new CharArrayWriter();
                PrintWriter w = new PrintWriter(cw);
                e.printStackTrace(w);
                w.close();
                System.out.println(cw.toString());
                status = "fail";
                commandInterface = new NoOpCommand("Exception occurred during operation");
            }
            // cache.put(transactionId,new CmdResult(transactionId, desc, result, status, Timestamp.now()));
            cache.put(transactionId,new CommandAction(transactionId, commandInterface, status, Timestamp.now()));
        }
    }

    //generate random number of 5 digits
    public int gen() {
        Random r = new Random( System.currentTimeMillis() );
        return 10000 + r.nextInt(20000);
    }

    private void periodicMethod() {
        // This method will run periodically
        Timestamp current = Timestamp.now();
        int count = 0;
        for(int transactionId : cache.keySet()){
            CommandAction commandAction = cache.get(transactionId);
            if(commandAction.getStatus() == CommandAction.Status.success || commandAction.getStatus() == CommandAction.Status.terminated){
                Timestamp lastUpdated = commandAction.getLastUpdated();

                long timeDifferenceInSeconds = (current.getMillis() - lastUpdated.getMillis())/1000;
                if(timeDifferenceInSeconds >= 60){
                    cache.remove(transactionId);
                    count++;
                }
            }
        }
        if(count > 0){
            System.out.println("Cache was last cleared at: " + current);
            System.out.println("The number of items removed from the cache is(are): " + count);
        }
    }

    public static Map<Integer, CommandAction> getCache() {
        return cache;
    }

    public void destroy() {
        // Shut down the scheduler when the servlet is being destroyed
        if (scheduler != null) {
            scheduler.shutdown();
        }
    }

}
