package com.okta;

import com.google.gson.Gson;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Map;
import java.util.Properties;

public class Authenticate {
    private static final Logger _logger = LogManager.getLogger(Authenticate.class);
    static Properties properties = new Properties();
    public static String encodedCredentials;

    static{
        FileInputStream fis = null;
        try {
            fis = new FileInputStream( new File(".//config//params.properties") );

            properties.load( fis );
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally
        {
            try
            {
                if (fis != null)
                    fis.close();
            }
            catch( IOException ioe )
            {
                _logger.warn( "Failed to close fis", ioe );
            }
        }
    }

    public String getToken(){

        encodedCredentials = Base64.getEncoder()
                .encodeToString((properties.getProperty("clientId") + ":" + properties.getProperty("clientSecret")).getBytes(StandardCharsets.UTF_8));

        String url = "https://" + properties.getProperty("oktaDomain") + "/oauth2/default/v1/token";

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .headers("Content-Type", "application/x-www-form-urlencoded",
                            "Authorization", "Basic " + encodedCredentials,
                            "Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString("grant_type="+properties.getProperty("grantType")
                            +"&scope="+properties.getProperty("scope")
                            +"&username="+properties.getProperty("username")
                            +"&password="+properties.getProperty("password")))
                    .build();

            HttpClient httpClient = HttpClient.newHttpClient();
            HttpResponse<?> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            Map<String, String> oktaResponseToken = new Gson().fromJson(response.body().toString(), Map.class);
            return oktaResponseToken.get("access_token");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public boolean isTokenValid(String token){
        String url = "https://" + properties.getProperty("oktaDomain") + "/oauth2/default/v1/introspect";

        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .headers("Content-Type", "application/x-www-form-urlencoded",
                            "Authorization", "Basic " + encodedCredentials,
                            "Accept", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString("token="+token
                            +"&token_type_hint="+properties.getProperty("tokenTypeHint")))
                    .build();

            HttpClient httpClient = HttpClient.newHttpClient();
            HttpResponse<?> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            Map<String, Object> oktaResponseToken = new Gson().fromJson(response.body().toString(), Map.class);
            //  String active = oktaResponseToken.get("active");
            return (Boolean) oktaResponseToken.get("active");

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }
}
