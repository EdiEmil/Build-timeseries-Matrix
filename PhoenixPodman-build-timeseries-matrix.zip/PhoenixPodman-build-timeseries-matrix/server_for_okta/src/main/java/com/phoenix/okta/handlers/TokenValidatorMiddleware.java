package com.phoenix.okta.handlers;

import com.google.gson.Gson;
import com.phoenix.okta.Authenticate;
import io.undertow.io.Receiver;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HttpString;
public class TokenValidatorMiddleware implements HttpHandler {
    private final HttpHandler next;

    public TokenValidatorMiddleware(HttpHandler next){
        this.next = next;
    }

    @Override
    public void handleRequest(HttpServerExchange httpServerExchange) throws Exception {

        String authorizationHeader = httpServerExchange.getRequestHeaders().getFirst(new HttpString("Authorization"));
        if (authorizationHeader == null || !authorizationHeader.startsWith("Basic ")) {
            httpServerExchange.setStatusCode(401); // Unauthorized
            httpServerExchange.getResponseSender().send("Unauthorized: Missing or invalid authorization");
            return;
        }

        final String[] body = {null};
        httpServerExchange.getRequestReceiver().receiveFullBytes(new Receiver.FullBytesCallback() {
            @Override
            public void handle(HttpServerExchange exchange, byte[] message) {
                body[0] = new String(message);
            }
        });
       // String body = readRequestBody(httpServerExchange.getInputStream());
      //  Map<String, Object> oktaResponseToken = new Gson().fromJson(body[0], Map.class);
        boolean isValidToken = validateToken(body[0].substring(6)); // token=

        if (!isValidToken) {
            httpServerExchange.setStatusCode(401); // Unauthorized
            httpServerExchange.getResponseSender().send("Unauthorized: Invalid token");
            return;
        }
        // Token is valid, proceed with the next handler
        next.handleRequest(httpServerExchange);
    }
    private boolean validateToken(String token){
        return Authenticate.isTokenValid(token);
    }
}
