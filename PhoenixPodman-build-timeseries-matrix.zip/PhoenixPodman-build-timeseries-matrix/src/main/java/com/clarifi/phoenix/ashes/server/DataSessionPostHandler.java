package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.task.BuildDataSession;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HeaderValues;
import io.undertow.util.Headers;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteException;
import org.apache.ignite.lang.IgniteFuture;
import org.apache.ignite.lang.IgniteInClosure;
import org.apache.logging.log4j.Logger;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;

import java.io.IOException;
import java.io.InputStream;
import java.util.Deque;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

public class DataSessionPostHandler extends CreateDataSessionHandler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(DataSessionPostHandler.class);
    private static final Tracer tracer = GlobalOpenTelemetry.getTracer("com.clarifi.phoenix.ashes.server.DataSessionPostHandler");

    private final ServerApp server;
    private int timeoutS = 5;

    public DataSessionPostHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        Span span = tracer.spanBuilder("handleRequest").startSpan();
        try (Scope scope = span.makeCurrent()) {
            handleParams(exchange);

            final PackedDataSession session = parseDataSession(exchange);
            span.setAttribute("sessionId", session.getId().toString());
            span.setAttribute("userId", session.getUserId().toString());

            final Ignite ignite = server.getIgnite();
            final IgniteCache<UUID, PackedDataSession> cache = getOrCreateUserCache(ignite, session.getUserId().toString());

            if (cache.containsKey(session.getId())) {
                span.setStatus(StatusCode.ERROR, "Data session already exists");
                exchange.setStatusCode(StatusCodes.BAD_REQUEST);
                final String message = String.format("Data session with id '%s' already exists", session.getUserId());
                exchange.getResponseSender().send(message);
            }
            else {
                session.setStatus(DataSession.Status.Initializing);
                cache.put(session.getId(), session);

                final long startedAt = System.nanoTime();
                final IgniteCompute compute = ignite.compute(ignite.cluster().forServers());

                Span buildSessionSpan = tracer.spanBuilder("buildDataSession").startSpan();
                try (Scope buildScope = buildSessionSpan.makeCurrent()) {
                    final IgniteFuture<Boolean> future = compute.callAsync(new BuildDataSession(session, cache.getName()));

                    try {
                        final Boolean result = future.get(timeoutS, TimeUnit.SECONDS);
                        sendSessionResult(session, result, exchange);
                        buildSessionSpan.setStatus(StatusCode.OK);
                    } catch (final IgniteException ex) {
                        handleException(ex, future, session, exchange, startedAt);
                        buildSessionSpan.setStatus(StatusCode.ERROR, "Failed to build data session");
                    } catch (final Throwable err) {
                        buildSessionSpan.setStatus(StatusCode.ERROR, err.getMessage());
                        err.printStackTrace(System.err);
                    }
                } finally {
                    buildSessionSpan.end();
                }
            }
        } catch (Exception e) {
            span.setStatus(StatusCode.ERROR, e.getMessage());
            throw e;
        } finally {
            span.end();
        }

        exchange.endExchange();
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }
    }

    private static PackedDataSession parseDataSession(HttpServerExchange exchange) throws IOException {
        final byte[] bytes;

        final HeaderValues requestEncoding = exchange.getRequestHeaders().get(Headers.CONTENT_ENCODING);
        if (requestEncoding != null && requestEncoding.contains(ENCODING_GZIP)) {
            final GZIPInputStream input = new GZIPInputStream(exchange.getInputStream());
            bytes = input.readAllBytes();
        }
        else {
            final InputStream input = exchange.getInputStream();
            bytes = input.readAllBytes();
        }

        final PackedDataSession.Reader reader = new PackedDataSession.IonReader();
        return (PackedDataSession) reader.read(bytes);
    }

    private void handleException(final IgniteException ex, final IgniteFuture<Boolean> future, final PackedDataSession session, final HttpServerExchange exchange, final long startedAt) {
        if (!future.isCancelled() && !future.isDone()) {
            future.listen(new IgniteInClosure<IgniteFuture<Boolean>>() {
                @Override
                public void apply(final IgniteFuture<Boolean> future) {
                    final double millis = (System.nanoTime() - startedAt) / 1_000_000d;
                    LOGGER.info("Data session '{}' loaded after {} seconds", session.getId(), millis / 1000d);
                }
            });
            sendSessionStatus(session, exchange);
        }
        else {

            session.setStatus(DataSession.Status.Failed);
            IgniteCache<UUID, PackedDataSession> cache = server.getIgnite().cache(session.getUserId().toString());
            cache.replace(session.getId(), session);
            sendSessionError(session, ex, exchange);
        }
    }
}