package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import com.clarifi.phoenix.ashes.common.*;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.*;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.logging.log4j.Logger;

import java.util.*;
import java.util.concurrent.*;

public class DataSessionGetTimeSeriesHandler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(DataSessionGetTimeSeriesHandler.class);

    private final ServerApp server;

    public DataSessionGetTimeSeriesHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        //-- Data sessionId is in the path (REST request)
        final PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        final String sessionId = pathMatch.getParameters().get("sessionId");

        //-- UserId is passed as a query parameter
        final String userId = exchange.getQueryParameters().get("userId").getFirst();

        final Ignite ignite = server.getIgnite();

        final String userCacheName = String.format(
                "%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, userId);

        final IgniteCache<UUID, PackedDataSession> userDataSessionCache = ignite.cache(userCacheName);
        if (userDataSessionCache == null) {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
            exchange.getResponseSender().send(String.format("User with id '%s' does have any sessions", userId));
            exchange.endExchange();

            return;
        }

        final DataSession session = userDataSessionCache.get(UUID.fromString(sessionId));
        if (session == null) {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
            exchange.getResponseSender().send(String.format(
                    "Data session '%s' does not exist for user '%s'", sessionId, userId));
            exchange.endExchange();

            return;
        }

        if (session.getStatus() != DataSession.Status.Ready) {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
            exchange.getResponseSender().send(String.format(
                    "Data session '%s' is not ready. Current status: %s",
                    sessionId,
                    userId,
                    session.getStatus()
            ));

            exchange.endExchange();

            return;
        }

        final BatchingThreadPool pool = server.getPool();
        final ExecutorService executor = server.getExecutor();
        final IgniteCompute compute = ignite.compute(ignite.cluster().forServers());

        final HeaderMap headers = exchange.getResponseHeaders();
        final HeaderValues encoding = headers.get(Headers.ACCEPT);
        if (encoding == null || encoding.contains(PhoenixMimeTypes.TEXT_ION)) {
            exchange.dispatch(executor, new IonStreamProducer(session, exchange, compute, pool));
        } else if (encoding.contains(PhoenixMimeTypes.TEXT_JSON)) {
            exchange.dispatch(executor, new JsonStreamProducer(session, exchange, compute, pool));
        } else {
            exchange.setStatusCode(StatusCodes.NOT_ACCEPTABLE);
            exchange.getResponseSender().send("Unsupported media type");
            exchange.endExchange();

            LOGGER.error("Unsupported media type request for sessionId: {}", sessionId);
        }
    }
}
