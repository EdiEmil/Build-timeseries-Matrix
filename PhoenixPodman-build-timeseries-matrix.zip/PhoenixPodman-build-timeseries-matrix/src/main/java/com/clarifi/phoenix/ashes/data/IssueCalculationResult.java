package com.clarifi.phoenix.ashes.data;

public class IssueCalculationResult {
  public int numIssues;
  public int[] issueIds;
  public TimeSeriesData[] data;

  public IssueCalculationResult(int numIssues) {
    this.numIssues = numIssues;
    issueIds = new int[numIssues];
    data = new TimeSeriesData[numIssues];
  }
}
