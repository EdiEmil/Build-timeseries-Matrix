package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.application.App;
import com.clarifi.common.util.Logging;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import com.clarifi.phoenix.ashes.StringandInteger.*;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.metrics.HelloHandler;
import com.clarifi.phoenix.ashes.metrics.OpenTelemetryConfig;
import com.sun.net.httpserver.HttpServer;
import io.opencensus.exporter.trace.zipkin.ZipkinExporterConfiguration;
import io.opencensus.exporter.trace.zipkin.ZipkinTraceExporter;
import io.undertow.Handlers;
import io.undertow.Undertow;
import io.undertow.server.HttpHandler;
import io.undertow.server.handlers.*;
import io.undertow.server.handlers.encoding.EncodingHandler;
import io.undertow.server.handlers.resource.FileResourceManager;
import io.undertow.server.handlers.resource.ResourceHandler;
import io.undertow.util.HttpString;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.query.QueryCursor;
import org.apache.ignite.cache.query.ScanQuery;
import org.apache.ignite.cluster.ClusterNode;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpDiscoveryMulticastIpFinder;
import org.apache.ignite.spi.tracing.Scope;
import org.apache.ignite.spi.tracing.TracingConfigurationCoordinates;
import org.apache.ignite.spi.tracing.TracingConfigurationParameters;
import org.apache.logging.log4j.Logger;

import javax.cache.Cache;
import java.io.File;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.file.Path;
import java.time.Duration;
import java.time.Instant;
import java.util.Collection;
import java.util.Collections;
import java.util.UUID;
import java.util.concurrent.*;

public class ServerApp {
    private static final Logger LOGGER = Logging.getLogger(ServerApp.class);

    public static final String PATH_API2 = "/api2";
    public static final String PREFIX_CACHE_USER_DATA_SESSIONS = "user-data-sessions";

    private final BlockingQueue<Runnable> queue;
    private final ExecutorService executor;

    private Ignite ignite;
    private BatchingThreadPool pool;

    public ServerApp() {
        // todo: replace with Glav's threading library
        queue = new ArrayBlockingQueue<>(32);
        executor = new ThreadPoolExecutor(
            2, 4, 5L, TimeUnit.MINUTES, queue);
    }

    public Ignite getIgnite() {
        return ignite;
    }

    public ExecutorService getExecutor() {
        return executor;
    }

    public BatchingThreadPool getPool() {
        return pool;
    }

    public void setPool(final BatchingThreadPool value) {
        this.pool = value;
    }

    public void start() {
        //register Zipkin exporter
        ZipkinTraceExporter.createAndRegister(
                ZipkinExporterConfiguration.builder().setV2Url("http://localhost:9411/api/v2/spans")
                        .setServiceName("ignite-cluster").build());
        final IgniteConfiguration cfg = new IgniteConfiguration();

        cfg.setClientMode(true);
        cfg.setPeerClassLoadingEnabled(true);
        cfg.setTracingSpi(new org.apache.ignite.spi.tracing.opencensus.OpenCensusTracingSpi());
        /*
        * sets the work directory for the ignite node, where it stores the runtime files, including Persistence Data, WAL (Write-Ahead Log),
        * Node Metadata, temporary files etc.
        * */
        cfg.setWorkDirectory(Path.of(System.getProperty("java.io.tmpdir"), "api-server").toString());

        // Setting up an IP Finder to ensure the client can locate the servers.
        final TcpDiscoveryMulticastIpFinder ipFinder = new TcpDiscoveryMulticastIpFinder();
        ipFinder.setAddresses(Collections.singletonList("127.0.0.1:47500..47509"));
        cfg.setDiscoverySpi(new TcpDiscoverySpi().setIpFinder(ipFinder));

        ignite = Ignition.start(cfg);
        // Enable trace sampling for transactions with 100% sampling rate
        ignite.tracingConfiguration().set(
                new TracingConfigurationCoordinates.Builder(Scope.SQL).build(),
                new TracingConfigurationParameters.Builder().withSamplingRate(1).build()
        );

        LOGGER.info("Started the client node");

        LOGGER.info("Node ID: {}\tNumber of Server Nodes Running: {}\tOS: {}\tJRE: {}",
                ignite.cluster().localNode().id(),
                ignite.cluster().forServers().nodes().size(),
                System.getProperty("os.name"),
                System.getProperty("java.runtime.name")
        );
        // Get and print the server node IDs
        for (final ClusterNode serverNode : ignite.cluster().forServers().nodes()) {
            LOGGER.info("Discovered server node ID: {}", serverNode.id());
        }
    }

    public static void main(final String[] args) throws Throwable {
        // Set up OpenTelemetry configuration
        OpenTelemetryConfig.setup();

        try {
            // Create HTTP server on port 8080
            HttpServer server = HttpServer.create(new InetSocketAddress(8087), 0);

            // Set up the handler for the "/hello" endpoint
            server.createContext("/hello", new HelloHandler(OpenTelemetryConfig.getHttpRequestCounter()));

            // Start the server
            server.setExecutor(null); // creates a default executor
            server.start();

            System.out.println("Server started on port 8087");

        } catch (IOException e) {
            e.printStackTrace();
        }


        App.initBeforeAnythingElse(args, 0, "Server App", "1.0.0");

        final ServerApp appServer = new ServerApp();

        final App instance = App.appMain(appServer::startup, appServer::shutdown);

        TimeUnit.SECONDS.sleep(5L);

        appServer.setPool(instance.getAppThreadPool());

        LOGGER.info("Server has started and it's ready to accept requests");
    }

    private void startup(){
        this.start();

        final HttpHandler createUser = new ResponseCodeHandler(StatusCodes.NOT_FOUND);
        final HttpHandler getUser = new ResponseCodeHandler(StatusCodes.NOT_FOUND);
        final HttpHandler logoutUser = new ResponseCodeHandler(StatusCodes.NOT_FOUND);

        final HttpHandler putNewDataSession = new LoggingHandler(new RequestBufferingHandler(new BlockingHandler(
                new DataSessionPutHandler(this)), 1));

        final HttpHandler getDataSession = new LoggingHandler(new EncodingHandler.Builder().build(null).wrap(
                new DataSessionGetHandler(this)));

        final HttpHandler postString = new LoggingHandler(new RequestBufferingHandler(new BlockingHandler(new StringPostHandler(this)),1));
        final HttpHandler postIgniteString = new LoggingHandler(new RequestBufferingHandler(new BlockingHandler(new StringPostIgniteHandler(this)),1));
        final HttpHandler postIgnite100String = new LoggingHandler(new RequestBufferingHandler(new BlockingHandler(new StringPostIgnite100Handler(this)),1));
        final HttpHandler getString = new LoggingHandler(new EncodingHandler.Builder().build(null).wrap(
                new StringGetHandler(this)));
        final HttpHandler getIgniteString = new LoggingHandler(new EncodingHandler.Builder().build(null).wrap(
                new StringGetIgniteHandler(this)));
        final HttpHandler postInteger = new LoggingHandler(new RequestBufferingHandler(new BlockingHandler(new IntPostHandler(this)),1));
        final HttpHandler getInteger = new LoggingHandler(new EncodingHandler.Builder().build(null).wrap(
                new IntGetHandler(this)));

        final HttpHandler getDataSessionStatus = new ResponseCodeHandler(StatusCodes.NOT_FOUND);
        final HttpHandler headDataSessionStatus = new ResponseCodeHandler(StatusCodes.NOT_FOUND);
        final HttpHandler getDataSessionTimeSeries = new LoggingHandler(new DataSessionGetTimeSeriesHandler(this));

        final HttpHandler cancelDataSession = new ResponseCodeHandler(StatusCodes.NOT_FOUND);

        final HttpHandler postNewDataSession = new LoggingHandler(new RequestBufferingHandler(new BlockingHandler(
                new DataSessionPostHandler(this)), 1));
        final HttpHandler deleteDataSession = new TokenValidatorMiddleware(new LoggingHandler(new DataSessionDeleteHandler(this)));

        final HttpHandler countIssues = new LoggingHandler(new DataSessionCountIssuesHandler(this));
        final HttpHandler getTimeSeries = new LoggingHandler(new GetTimeSeriesHandler(this));
        final HttpHandler getTimeSeriesSlice = new LoggingHandler(new GetTimeSeriesSliceHandler(this));
        final HttpHandler getCrossSectional = new ResponseCodeHandler(StatusCodes.NOT_FOUND);


        final HttpHandler fallback = new RequestDumpingHandler(new ResponseCodeHandler(StatusCodes.BAD_REQUEST));

        ResourceHandler resourceHandler = new ResourceHandler(new FileResourceManager(new File("C:\\Users\\nicolae_ovidiu\\Desktop\\Phoenix folder\\PhoenixPodman-build-timeseries-matrix\\static_web\\swagger"), 1024))

                .addWelcomeFiles("index.html")

                .setDirectoryListingEnabled(true);

        final PathHandler handler = Handlers.path()
                .addPrefixPath("/swagger-ui", resourceHandler)
                .addPrefixPath(PATH_API2, Handlers.routing()
                        .get("/user/get/{userId}", getUser)
                        .put("/user/create/{userId}", createUser)
                        .get("/user/logout/{userId}", logoutUser)

                        .post("/string-post", postString)
                        .post("/string-postIgnite", postIgniteString)
                        .post("/string-postIgnite100", postIgnite100String)
                        .get("/string-get",getString)
                        .get("/string-getIgnite",getIgniteString)
                        .post("/integer-post", postInteger)
                        .get("/integer-get",getInteger)

                        .put("/data-session-put/new", putNewDataSession)
                        .post("/data-session/new", postNewDataSession)
                        .get("/data-session/{sessionId}", getDataSession)
                        .get("/data-session/status/{sessionId}", getDataSessionStatus)
                        .add(HttpString.tryFromString("HEAD"), "/data-session/status/{sessionId}", headDataSessionStatus)
                        .get("/data-session/cancel/{sessionId}", cancelDataSession)
                        .get("/data-session/time-series/{sessionId}", getDataSessionTimeSeries)
                        .delete("/data-session/delete/{sessionId}", deleteDataSession)
                        .get("/data-sessions/count-issues/{userId}", countIssues)

                        .get("/time-series/{issueId}/{dataItemId}", getTimeSeries)
                        .get("/time-series/{issueId}/{dataItemId}/{date}", getTimeSeries)
                        .get("/time-series/{issueId}/{dataItemId}/{startDate}/{endDate}", getTimeSeriesSlice)
                        .get("/cross-sectional/{issueId}/{date}", getCrossSectional)
                        .get("/cross-sectional/{issueId}/{date}/{dataItemId}", getCrossSectional)

                        .setFallbackHandler(fallback)
                );

        final Undertow httpServer = Undertow.builder()
                .addHttpListener(8081,"localhost")
                .setHandler(handler)
                .build();

        httpServer.start();

        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(new CacheCleanerTask(ignite), 0, 20, TimeUnit.MINUTES);
    }

    private void shutdown(){}

    private static class CacheCleanerTask implements Runnable {
        private final Ignite ignite;

        CacheCleanerTask(final Ignite ignite) {
            this.ignite = ignite;
        }

        @Override
        public void run() {
            LOGGER.debug("Clearing Caches which are not used for over 20 minutes");
            Collection<String> cacheList = ignite.cacheNames();

            final Instant currentTime = Instant.now();

            for (final String cacheName : cacheList) {
                final IgniteCache<UUID, PackedDataSession> userDataSessionCache = ignite.cache(cacheName);
                try (QueryCursor<Cache.Entry<UUID, PackedDataSession>> cursor =userDataSessionCache.query(new ScanQuery<>())){
                    for (Cache.Entry<UUID, PackedDataSession> entry : cursor) {
                        long minutesDifference = Duration.between(entry.getValue().getLastAccessedAt(),currentTime).toMinutes();
                        if (minutesDifference > 20) {
                            final String userCacheName = String.format(
                                    "%s:%s", ServerApp.PREFIX_CACHE_USER_DATA_SESSIONS, entry.getValue().getUserId());
                            ignite.cache(userCacheName).clear();

                            LOGGER.debug("Cache '"+userCacheName+ "' is cleared");
                        }
                    }
                }
            }
        }
    }
}
