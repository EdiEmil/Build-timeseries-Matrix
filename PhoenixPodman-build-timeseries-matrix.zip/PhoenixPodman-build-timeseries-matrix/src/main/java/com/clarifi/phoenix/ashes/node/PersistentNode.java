package com.clarifi.phoenix.ashes.node;

import com.clarifi.phoenix.ashes.common.Common;
import org.apache.ignite.*;
import org.apache.ignite.configuration.IgniteConfiguration;

import java.lang.reflect.Method;

/**
 * A class to load some sample data into Ignite caches
 */
public class PersistentNode extends REPLNode {

  private Ignite _ignite;

  public final static void main(String[] args)
  {
    try
    {
      BaseNode.nodeMain(args, PersistentNode.class);
    }
    catch (Throwable t)
    {
      displayFatalErrorMessage(t);
      exit(-1);
    }
  }

  public static void main2(String[] args) throws IgniteException
  {
    //this will capture CTRL-C as an exit command
//    Runtime.getRuntime().addShutdownHook(new ShutdownHookThread(ignite));


    // Disconnect from the cluster.
//    ignite.close();
  }

  private static void loadIntToStringValues( Ignite ignite, String cacheName, int numValues)
  {
    // Create an IgniteCache and put some values in it.
    IgniteCache<Integer, String> cache = ignite.getOrCreateCache(cacheName);

    for (int i = 0; i < numValues; ++i){
      cache.put(i, "Issue Name " + i);
    }

    System.out.println(">> Created the cache '" + cacheName + "' and added the values.");
  }

  @Override
  public String getNodeDescription() {
    return "com.clarifi.phoenix.ashes.node.PersistentNode";
  }

  @Override
  protected void initNode() {
    super.initNode();

//    IgniteConfiguration cfg = com.clarifi.phoenix.ashes.common.Common.igniteClientConfiguration();
    IgniteConfiguration cfg = Common.ignitePersistentServerConfiguration();

    // Starting the node
    _ignite = Ignition.start(cfg);
  }

  @Override
  protected void doShutdown() {
    super.doShutdown();

    // Disconnect from the cluster.
    _ignite.close();
  }

  /**
   * Display the fatal error that occurred
   * @param t the throwable that was thrown
   */
  private final static void displayFatalErrorMessage(Throwable t)
  {
    try
    {
      //send it to err first thing
      t.printStackTrace(System.err);

      //do this with Reflection since we do not want to load
      //Swing Components unless we have to
      Class dlgClass       = Class.forName("javax.swing.JOptionPane");
      Class componentClass = Class.forName("java.awt.Component");
      Method msgDlg        = dlgClass.getMethod("showMessageDialog",
        new Class[]{ componentClass,
          Object.class,
          String.class,
          Integer.TYPE });
      String linSep = System.getProperty("line.separator");
      String msg = "Fatal Error in Data Cache Server!" +
        linSep + linSep + t.getMessage();

      msgDlg.invoke(null, new Object[]{ null, msg, "Fatal Error!",
        Integer.valueOf(dlgClass.getField("ERROR_MESSAGE").getInt(null))});
    }
    catch (Throwable tt) {/** ignore */ }
  }


}
