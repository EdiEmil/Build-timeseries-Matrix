package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import com.clarifi.concurrent.Unification;
import com.clarifi.concurrent.UnitedFuture;
import com.clarifi.concurrent.batch.BatchBuilder;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import com.clarifi.concurrent.batch.DecompContinuousBatch;
import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PhoenixMimeTypes;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.StatusCodes;
import org.apache.ignite.IgniteCompute;
import org.apache.logging.log4j.Logger;

import java.util.List;
import java.util.concurrent.atomic.LongAdder;
import java.util.function.Function;

public abstract class GenericStreamProducer implements Runnable {
    private static final Logger LOGGER = Logging.getLogger(GenericStreamProducer.class);

    protected final DataSession session;
    protected final HttpServerExchange exchange;
    protected final IgniteCompute compute;
    protected final BatchingThreadPool pool;

    public GenericStreamProducer(final DataSession session,
                                 final HttpServerExchange exchange,
                                 final IgniteCompute compute,
                                 final BatchingThreadPool pool) {
        this.session = session;
        this.exchange = exchange;
        this.compute = compute;
        this.pool = pool;
    }

    @Override
    public void run() {
        final long startedAt = System.nanoTime();

        exchange.setStatusCode(StatusCodes.OK);
        exchange.getResponseHeaders().put(
                io.undertow.util.Headers.CONTENT_TYPE,
                getResponseMimeType()
        );

        final BatchBuilder<Long, List<Integer>> builder = BatchBuilder.builderForCompleterFunction(
                Unification.UniteOrFailOnFirstFailure,
                new Function<List<List<Integer>>, Long>() {
                    @Override
                    public Long apply(final List<List<Integer>> lists) {
                        final LongAdder total = new LongAdder();

                        for (final List<Integer> children : lists) {
                            for (final Integer child : children) {
                                total.add(child.intValue());
                            }
                        }

                        return Long.valueOf(total.sumThenReset());
                    }
                }
        );

        final DecompContinuousBatch<Long, List<Integer>> batch = builder.
                forBatchType_DecompContinuous().buildForCollectorOrCompleterFunction();

        final StreamingSenderThread sender = new StreamingSenderThread(exchange);

        final UnitedFuture<Long, List<Integer>> future = prepareBatch(batch, sender);
        sender.start();
        writeHeader(session, sender);

        try {
            final Long bytesSent = future.get();
            writeFooter(session, sender);

            final double millis = (System.nanoTime() - startedAt) / 1_000_000d;
            LOGGER.info(
                    "{Thread:{}} Sent {} bytes for data session '{}' in {} seconds",
                    Thread.currentThread().getName(),
                    bytesSent.longValue(),
                    session.getId(),
                    Double.valueOf(millis / 1000d)
            );
        } catch (final Throwable err) {
            LOGGER.error("Error processing data session '{}': {}", session.getId(), err.getMessage());
        } finally {
            sender.end();
        }
    }

    protected String getResponseMimeType() {
        return PhoenixMimeTypes.TEXT_ION;
    }

    protected abstract UnitedFuture<Long, List<Integer>> prepareBatch(
            DecompContinuousBatch<Long, List<Integer>> batch, StreamingSenderThread sender);

    protected abstract void writeHeader(DataSession session, StreamingSenderThread sender);
    protected abstract void writeFooter(DataSession session, StreamingSenderThread sender);
}
