package com.clarifi.phoenix.ashes.server;

import com.clarifi.concurrent.UnitedFuture;
import com.clarifi.concurrent.batch.BatchingThreadPool;
import com.clarifi.concurrent.batch.DecompContinuousBatch;
import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PhoenixDate;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;
import com.clarifi.phoenix.ashes.common.PhoenixMimeTypes;
import io.undertow.server.HttpServerExchange;
import org.apache.ignite.IgniteCompute;

import java.nio.charset.StandardCharsets;
import java.util.List;

public class JsonStreamProducer extends GenericStreamProducer {

    public JsonStreamProducer(final DataSession session,
                              final HttpServerExchange exchange,
                              final IgniteCompute compute,
                              final BatchingThreadPool pool) {
        super(session, exchange, compute, pool);
    }

    @Override
    protected UnitedFuture<Long, List<Integer>> prepareBatch(final DecompContinuousBatch<Long, List<Integer>> batch,
                                                             final StreamingSenderThread sender) {
        final UnitedFuture<Long, List<Integer>> future = batch.submitToPool(pool);
        for (final int issueId : session.getIssues()) {
            batch.addCallable(new JsonTimeSeriesTask(
                    issueId,
                    session,
                    compute,
                    sender
            ));
        }

        batch.batchFullyDefined();

        return future;
    }

    @Override
    protected void writeHeader(final DataSession session, final StreamingSenderThread sender) {
        final StringBuilder header = new StringBuilder();
        header.append('{').append("\n");
        header.append("\"sessionId\": \"").append(session.getId()).append("\",\n");
        header.append("\"userId\": \"").append(session.getUserId()).append("\",\n");

        final PhoenixDateRange range = session.getRange();
        final PhoenixDate startDate = range.getStart();
        final PhoenixDate endDate = range.getEnd();
        header.append("\"startDate\": \"").append(startDate.getYear()).append('-').append(startDate.getMonth()).append('-').append(startDate.getDayOfMonth()).append("\",\n");
        header.append("\"endDate\": \"").append(endDate.getYear()).append('-').append(endDate.getMonth()).append('-').append(endDate.getDayOfMonth()).append("\",\n");

        header.append("columns: [\"issueId\", \"date\", ");
        for (final int dataItemId : session.getDataItems()) {
            header.append("\"valueOf-").append(dataItemId).append("\", ");
        }
        header.append("],\n");

        header.append("\"data\": [\n");

        sender.queueText(header.toString().getBytes(StandardCharsets.UTF_8));
    }

    @Override
    protected void writeFooter(final DataSession session, final StreamingSenderThread sender) {
        final StringBuilder footer = new StringBuilder();
        footer.append("],\n");
        footer.append("\"data_crc32\": ").append(sender.getDataChecksum()).append(",\n");
        footer.append("\"data_length\": ").append(sender.getDataCount()).append("\n");
        footer.append('}');

        sender.queueText(footer.toString().getBytes(StandardCharsets.UTF_8));
    }

    @Override
    protected String getResponseMimeType() {
        return PhoenixMimeTypes.TEXT_JSON;
    }
}
