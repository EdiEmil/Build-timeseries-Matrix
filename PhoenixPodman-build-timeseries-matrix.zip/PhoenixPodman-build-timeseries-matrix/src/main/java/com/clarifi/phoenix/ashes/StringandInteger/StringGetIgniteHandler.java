package com.clarifi.phoenix.ashes.StringandInteger;

import com.clarifi.phoenix.ashes.server.ServerApp;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.configuration.CacheConfiguration;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class StringGetIgniteHandler implements HttpHandler {

    private final ServerApp server;
    private static final Tracer tracer = GlobalOpenTelemetry.getTracer("com.clarifi.phoenix.ashes.server.StringGetIgniteHandler");

    public StringGetIgniteHandler(ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) {
        // Start a new span for the request
        Span span = tracer.spanBuilder("handleRequest").startSpan();
        try (Scope scope = span.makeCurrent()) {
            // Retrieve the key from query parameters
            final String keyValue = exchange.getQueryParameters().get("key").getFirst();
            long key = keyValue == null ? -1L : Long.parseLong(keyValue); // Use long here

            // Initialize Ignite cache with Long keys
            IgniteCache<Long, String> cache;
            final Ignite ignite = server.getIgnite();

            ignite.cluster().active(true);

            CacheConfiguration<Long, String> cacheConfig = new CacheConfiguration<>("myCache");
            cache = ignite.getOrCreateCache(cacheConfig);

            // Retrieve the value from the cache using a long key
            String value = cache.get(key);
            if (value != null) {
                System.out.println(value);
                exchange.getResponseSender().send(String.format("The value for key \"%s\" is \"%s\"", key, value));
                span.setStatus(StatusCode.OK); // Mark span as successful
            } else {
                throw new IllegalArgumentException("No value found for key: " + key);
            }
        } catch (IllegalArgumentException e) {
            // Log the error and set span status to ERROR
            span.setStatus(StatusCode.ERROR, "Error: " + e.getMessage());
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
            exchange.getResponseSender().send("Error: " + e.getMessage());
        } catch (Exception e) {
            // Log any other errors
            span.setStatus(StatusCode.ERROR, "Internal error: " + e.getMessage());
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Internal server error: " + e.getMessage());
        } finally {
            // End the span
            span.end();
            exchange.endExchange();
        }
    }

    public static String readFromExchange(HttpServerExchange exchange) {
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (Exception e) {
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Error reading request body: " + e.getMessage());
            return null;
        }

        return stringBuilder.toString();
    }
}
