package com.clarifi.phoenix.ashes.StringandInteger;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.server.ServerApp;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteAtomicSequence;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Deque;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class StringPostIgnite100Handler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(StringPostIgnite100Handler.class);
    private static final Tracer tracer = GlobalOpenTelemetry.getTracer("com.clarifi.phoenix.ashes.server.StringPostIgnite100Handler");

    private final ServerApp server;
    private int timeoutS = 5;

    // A map to store the key-value pairs
    private final Map<Long, String> savedEntries = new ConcurrentHashMap<>();

    public StringPostIgnite100Handler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        Span span = tracer.spanBuilder("handleRequest").startSpan();
        try (Scope scope = span.makeCurrent()) {
            handleParams(exchange);
            String value = readFromExchange(exchange);

            final Ignite ignite = server.getIgnite();

            // Activate cluster (important after restart)
            ignite.cluster().active(true);
            
            // Use IgniteAtomicSequence to ensure unique keys across restarts and nodes
            IgniteAtomicSequence atomicSequence = ignite.atomicSequence("uniqueKeySeq", 0, true);

            // Configure a persistent cache
            CacheConfiguration<Long, String> cacheConfig = new CacheConfiguration<>("myCache");
            cacheConfig.setCacheMode(CacheMode.PARTITIONED); // Adjust the cache mode as needed
            cacheConfig.setAtomicityMode(org.apache.ignite.cache.CacheAtomicityMode.ATOMIC); // Optional: For performance
            cacheConfig.setBackups(1); // Set the number of backup copies for high availability
            cacheConfig.setDataRegionName("persistentRegion"); // Use a persistent data region

            IgniteCache<Long, String> cache = ignite.getOrCreateCache(cacheConfig);

            // Save multiple values with unique keys in a loop
            StringBuilder httpResponse = new StringBuilder("ok");
            for (int i = 0; i <= 99; i++) {
                long key = atomicSequence.incrementAndGet(); // Generate a unique key
                String valueM = String.format("%s saved with custom number %d", value, i);
                cache.put(key, valueM);  // Cache the value
                savedEntries.put(key, valueM);  // Keep the key-value in the map

                // Append to the response for each cached entry
                httpResponse.append(String.format("%n%n%n  The key for value \"%s\" is \"%s\"%n", cache.get(key), key));
            }

            // Send the response back to the client
            exchange.getResponseSender().send(httpResponse.toString());
            span.setStatus(StatusCode.OK);
        } catch (Exception e) {
            LOGGER.error("Error handling request: {}", e.getMessage(), e);
            span.setStatus(StatusCode.ERROR, "Error processing request");
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Internal server error: " + e.getMessage());
        } finally {
            span.end();
            exchange.endExchange();
        }
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }
    }

    public static String readFromExchange(HttpServerExchange exchange) {
        StringBuilder stringBuilder = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (Exception e) {
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Error reading request body: " + e.getMessage());
            return null;
        }

        return stringBuilder.toString();
    }
}
