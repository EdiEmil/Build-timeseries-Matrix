package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import io.undertow.io.IoCallback;
import io.undertow.io.Sender;
import io.undertow.server.HttpServerExchange;
import org.apache.logging.log4j.Logger;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.LinkedList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;
import java.util.zip.CRC32;
import java.util.zip.Checksum;

public class StreamingSenderThread extends Thread {
    private static final Logger LOGGER = Logging.getLogger(StreamingSenderThread.class);

    private final HttpServerExchange exchange;
    private final List<ByteBuffer> queue;
    private volatile boolean terminate;
    private volatile boolean working;
    private final Checksum dataChecksum;
    private long dataCount;

    public StreamingSenderThread(final HttpServerExchange exchange) {
        super();

        this.exchange = exchange;

        queue = new LinkedList<>();
        dataChecksum = new CRC32();
        dataCount = 0L;
    }

    @Override
    public void run() {
        final IoCallback callback = new IoCallback() {
            @Override
            public void onComplete(final HttpServerExchange exchange, Sender sender) {
                working = false;

                LOGGER.debug("Finished sending bytes to client");
            }

            @Override
            public void onException(final HttpServerExchange exchange, final Sender sender,
                                    final IOException e) {
                working = false;
                terminate = true;

                LOGGER.error("Error sending bytes to client: {}", e.getMessage());

                sender.close();
                exchange.endExchange();
            }
        };

        final Sender sender = exchange.getResponseSender();

        while (!terminate) {
            if (working) {
                try {
                    TimeUnit.MILLISECONDS.sleep(250L);
                } catch (final InterruptedException ex) {
                    LOGGER.debug("Interrupted while waiting for sender to finish sending chunk");
                    break;
                }
            } else {
                try {
                    final ByteBuffer head;
                    synchronized (this) {
                        head = queue.removeFirst();
                    }

                    if (head == null) {
                        sender.close();
                    } else {
                        working = true;
                        sender.send(head, callback);
                    }
                } catch (final NoSuchElementException empty) {
                    try {
                        TimeUnit.MILLISECONDS.sleep(250L);
                    } catch (final InterruptedException ex) {
                        LOGGER.debug("Interrupted while waiting for new new data to send");
                        break;
                    }
                }
            }
        }

        if (!exchange.isComplete()) {
            exchange.endExchange();
        }
    }

    public void start() {
        queue.clear();
        dataChecksum.reset();
        dataCount = 0L;

        working = false;
        terminate = false;

        super.start();
    }

    public long getDataChecksum() {
        return dataChecksum.getValue();
    }

    public long getDataCount() {
        return dataCount;
    }

    public synchronized void queueText(final byte[] bytes) {
        queue.add(ByteBuffer.wrap(bytes));
    }

    public synchronized void queueData(final byte[] bytes) {
        queue.add(ByteBuffer.wrap(bytes));

        dataChecksum.update(bytes);
        dataCount++;
    }

    public synchronized void end() {
        queue.add(null);
    }
}
