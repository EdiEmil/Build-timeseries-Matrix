package com.clarifi.phoenix.ashes.data;

public class IssueData {
  int issueId;
  String companyName;
  String ticker;
  String sector;

  public IssueData(int issueId) {
  }

  /**
   *   Create a time series data of specified length with random data
   */
  public static IssueData fill(int issueId) {
    IssueData result = new IssueData(issueId);

    result.issueId = issueId;
    result.companyName = "Company Name " + issueId;
    result.ticker = "Ticker " + issueId;
    result.sector = "Sector " + issueId;

    return result;
  }
}
