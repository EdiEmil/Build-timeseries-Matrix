package com.clarifi.phoenix.ashes.common;

import org.apache.ignite.cache.CacheMode;
import org.apache.ignite.cache.CacheRebalanceMode;
import org.apache.ignite.cache.PartitionLossPolicy;
import org.apache.ignite.configuration.CacheConfiguration;

import java.util.List;

public class CrossSectionalDataCache {
    private static final String NAME = "CROSS_SECTIONAL";

    public static String getName() {
        return NAME;
    }

    public static CacheConfiguration<CrossSectionalDataKey, List<IssueDataSlicedByDate>> getCrossSectionalConfig() {
        final CacheConfiguration<CrossSectionalDataKey, List<IssueDataSlicedByDate>> config = new CacheConfiguration<>();
        config.setName(NAME);
        config.setCacheMode(CacheMode.PARTITIONED);
        config.setBackups(2);
        config.setRebalanceMode(CacheRebalanceMode.SYNC);
        config.setPartitionLossPolicy(PartitionLossPolicy.READ_ONLY_SAFE);

        return config;
    }

}
