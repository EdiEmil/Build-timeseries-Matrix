package com.clarifi.phoenix.ashes.StringandInteger;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.server.ServerApp;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Deque;
import java.util.Map;
import java.util.Random;

public class IntPostHandler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(StringPostHandler.class);
    private static final Tracer tracer = GlobalOpenTelemetry.getTracer("com.clarifi.phoenix.ashes.server.IntPostHandler");
    int timeoutS = 5;
    private final ServerApp server;


    public IntPostHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        // Start a span for the request
        Span span = tracer.spanBuilder("handleRequest").startSpan();
        try (Scope scope = span.makeCurrent()) {
            handleParams(exchange);
            String value = readFromExchange(exchange);
            Integer integerValue = Integer.parseInt(value);
            System.out.println(integerValue);

            int key = generateRandomSixDigitNumber();
            IgniteCache<Integer, Integer> cache;
            final Ignite ignite = server.getIgnite();
            CacheConfiguration<Integer, Integer> cacheConfig = new CacheConfiguration<>("myCache");
            cache = ignite.getOrCreateCache(cacheConfig);

            cache.put(key, integerValue);
            System.out.println("Stored: " + integerValue + " with key: " + key);
            System.out.println("Value with key: " + key + "  is:   " + cache.get(key));
            exchange.getResponseSender().send(String.format("The key for value \"%s\" is \"%s\"", integerValue, key));
            span.setStatus(StatusCode.OK); // Mark span as successful
        } catch (Exception e) {
            // Log the error and set span status to ERROR
            LOGGER.error("Error handling request: {}", e.getMessage(), e);
            span.setStatus(StatusCode.ERROR, "Error processing request");
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Internal server error: " + e.getMessage());
        } finally {
            // End the span
            span.end();
            exchange.endExchange();
        }
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }
    }

    public static String readFromExchange(HttpServerExchange exchange) {
        StringBuilder stringBuilder = new StringBuilder();

        // Set up a reader to read the request body
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (Exception e) {
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Error reading request body: " + e.getMessage());
            return null;
        }

        return stringBuilder.toString();
    }

    public static int generateRandomSixDigitNumber() {
        Random random = new Random();
        return 100000 + random.nextInt(900000); // Generates a number between 100000 and 999999
    }
}
