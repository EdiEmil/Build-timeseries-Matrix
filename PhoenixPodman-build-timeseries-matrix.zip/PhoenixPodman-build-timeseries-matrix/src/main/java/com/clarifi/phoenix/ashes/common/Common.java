package com.clarifi.phoenix.ashes.common;

import org.apache.ignite.configuration.DataRegionConfiguration;
import org.apache.ignite.configuration.DataStorageConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.spi.discovery.tcp.TcpDiscoverySpi;
import org.apache.ignite.spi.discovery.tcp.ipfinder.multicast.TcpDiscoveryMulticastIpFinder;

import java.util.Collections;

public class Common {

  public final static String SAMPLE_CACHE = "issueNames";

  public final static String TIMESERIES_DATA_CACHE = "timeSeries";
  public final static String SECURITY_MASTER_CACHE = "securityMaster";

  public static IgniteConfiguration igniteClientConfiguration() {
    // Preparing IgniteConfiguration using Java APIs
    IgniteConfiguration cfg = new IgniteConfiguration();

    // The node will be started as a client node.
    cfg.setClientMode(true);

    // Classes of custom Java logic will be transferred over the wire from this app.
    cfg.setPeerClassLoadingEnabled(true);

    // Setting up an IP Finder to ensure the client can locate the servers.
    TcpDiscoverySpi discoverySpi = createDiscoverySpi();
    cfg.setDiscoverySpi(discoverySpi);

    return cfg;
  }


  public static IgniteConfiguration ignitePersistentServerConfiguration() {
    // Preparing IgniteConfiguration using Java APIs
    IgniteConfiguration cfg = new IgniteConfiguration();

    // The node will be started as a server node.
    cfg.setClientMode(false);

    // Classes of custom Java logic will be transferred over the wire from this app.
    cfg.setPeerClassLoadingEnabled(true);

    //data storage configuration
    DataStorageConfiguration storageCfg = new DataStorageConfiguration();
    DataRegionConfiguration defaultDataRegionCfg = storageCfg.getDefaultDataRegionConfiguration();
    defaultDataRegionCfg.setMaxSize(1 * 1024 * 1024 * 1024).setPersistenceEnabled(true);

    cfg.setDataStorageConfiguration(storageCfg);

    // Setting up an IP Finder to ensure the client can locate the servers.
    TcpDiscoveryMulticastIpFinder ipFinder = new TcpDiscoveryMulticastIpFinder();
    ipFinder.setAddresses(Collections.singletonList("127.0.0.1:47500..47509"));

    TcpDiscoverySpi discoverySpi = createDiscoverySpi();
    cfg.setDiscoverySpi(discoverySpi);

    return cfg;
  }

  public static TcpDiscoverySpi createDiscoverySpi() {
    // Setting up an IP Finder to ensure the client can locate the servers.
    TcpDiscoveryMulticastIpFinder ipFinder = new TcpDiscoveryMulticastIpFinder();
    ipFinder.setAddresses(Collections.singletonList("127.0.0.1:47500..47509"));
    TcpDiscoverySpi result = new TcpDiscoverySpi().setIpFinder(ipFinder);

    return result;
  }
}
