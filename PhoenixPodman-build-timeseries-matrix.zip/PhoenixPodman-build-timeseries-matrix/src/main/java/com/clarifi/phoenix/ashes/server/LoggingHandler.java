package com.clarifi.phoenix.ashes.server;

import com.clarifi.common.util.Logging;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import org.apache.logging.log4j.Logger;

public class LoggingHandler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(LoggingHandler.class);

    private final HttpHandler next;

    public LoggingHandler(final HttpHandler next) {
        this.next = next;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        LOGGER.info("{Thread:{}} Request method: {}, Request path: {}, Request body size: {}",
            Thread.currentThread().getName(),
            exchange.getRequestMethod(),
            exchange.getRequestPath(),
            exchange.getRequestContentLength()
        );

        next.handleRequest(exchange);
    }
}
