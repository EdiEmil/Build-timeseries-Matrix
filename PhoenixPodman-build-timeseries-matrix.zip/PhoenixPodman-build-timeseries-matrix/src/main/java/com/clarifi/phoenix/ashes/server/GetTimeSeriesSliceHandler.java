package com.clarifi.phoenix.ashes.server;

import com.amazon.ion.*;
import com.amazon.ion.system.IonSystemBuilder;
import com.clarifi.phoenix.ashes.common.*;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import com.clarifi.phoenix.ashes.task.GetTimeSeriesSlices;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.Headers;
import io.undertow.util.PathTemplateMatch;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCompute;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class GetTimeSeriesSliceHandler implements HttpHandler {
    private final ServerApp server;

    public GetTimeSeriesSliceHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        final PathTemplateMatch pathMatch = exchange.getAttachment(PathTemplateMatch.ATTACHMENT_KEY);
        final String issueId = pathMatch.getParameters().get("issueId");
        final String dataItemId = pathMatch.getParameters().get("dataItemId");

        final Ignite ignite = server.getIgnite();
        final IgniteCompute compute = ignite.compute();

        final TimeSeriesDataKey key = TimeSeriesDataCache.createKey(
                Integer.parseInt(issueId),
                Integer.parseInt(dataItemId)
        );

        final PhoenixDate startDate = parseDate("startDate", pathMatch);
        final PhoenixDate endDate = parseDate("endDate", pathMatch);

        final List<IssueDataSlicedByDataItem> slices = compute.affinityCall(
                TimeSeriesDataCache.getName(),
                key,
                new GetTimeSeriesSlices(
                        Integer.parseInt(issueId),
                        Integer.parseInt(dataItemId),
                        new PhoenixDateRange(startDate, endDate).getPackedValue()
                )
        );

        if (slices != null) {
            exchange.setStatusCode(StatusCodes.OK);

            final ByteArrayOutputStream stream = new ByteArrayOutputStream();
            final IonSystem ion = IonSystemBuilder.standard().build();
            final IonWriter writer = ion.newTextWriter(stream);

            final List<IonStruct> results = new ArrayList<>();
            for (final IssueDataSlicedByDataItem cursor : slices) {
                final IonStruct struct = ion.newEmptyStruct();
                struct.add("issueId", ion.newInt(cursor.getIssueId()));
                struct.add("dataItemId", ion.newInt(cursor.getDataItemId()));

                final PhoenixDateRange range = PhoenixDateRange.fromPackedValue(cursor.getDateRange());
                struct.add("range", PhoenixDateRange.toIon(range, ion));

                final List<IonValue> points = new LinkedList<>();
                for (final Double item : cursor.getValues()) {
                    points.add(ion.newDecimal(item.doubleValue()));
                }

                struct.add("values", ion.newList(points));

                results.add(struct);
            }

            ion.newList(results).writeTo(writer);

            final byte[] payload = stream.toByteArray();

            exchange.getResponseHeaders().put(Headers.CONTENT_LENGTH, Integer.toString(payload.length));
            exchange.getResponseHeaders().put(Headers.CONTENT_TYPE, PhoenixMimeTypes.TEXT_ION);

            exchange.getResponseSender().send(ByteBuffer.wrap(payload));
        } else {
            exchange.setStatusCode(StatusCodes.NOT_FOUND);
        }

        exchange.endExchange();
    }

    private PhoenixDate parseDate(final String name, final PathTemplateMatch match) {
        final String date = match.getParameters().get(name);
        if (date == null || date.isEmpty() || date.isBlank()) {
            return null;
        }

        final LocalDate localDate = LocalDate.parse(date);
        return PhoenixDate.fromLocalDate(localDate);
    }
}
