package com.clarifi.phoenix.ashes.StringandInteger;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.DataSession;
import com.clarifi.phoenix.ashes.common.PackedDataSession;
import com.clarifi.phoenix.ashes.server.DataSessionPostHandler;
import com.clarifi.phoenix.ashes.server.ServerApp;
import com.clarifi.phoenix.ashes.task.BuildDataSession;
import io.opentelemetry.api.GlobalOpenTelemetry;
import io.opentelemetry.api.trace.Span;
import io.opentelemetry.api.trace.StatusCode;
import io.opentelemetry.api.trace.Tracer;
import io.opentelemetry.context.Scope;
import io.undertow.server.HttpHandler;
import io.undertow.server.HttpServerExchange;
import io.undertow.util.HeaderValues;
import io.undertow.util.Headers;
import io.undertow.util.StatusCodes;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteCompute;
import org.apache.ignite.IgniteException;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.lang.IgniteFuture;
import org.apache.ignite.lang.IgniteInClosure;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Deque;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import java.util.zip.GZIPInputStream;

public class StringPostHandler implements HttpHandler {
    private static final Logger LOGGER = Logging.getLogger(StringPostHandler.class);
    private static final Tracer tracer = GlobalOpenTelemetry.getTracer("com.clarifi.phoenix.ashes.server.StringPostHandler");

    private final ServerApp server;
    private int timeoutS = 5;

    public StringPostHandler(final ServerApp server) {
        this.server = server;
    }

    @Override
    public void handleRequest(final HttpServerExchange exchange) throws Exception {
        // Start a span for the request
        Span span = tracer.spanBuilder("handleRequest").startSpan();
        try (Scope scope = span.makeCurrent()) {
            handleParams(exchange);
            String value = readFromExchange(exchange);
            System.out.println(value);

            int key = generateRandomSixDigitNumber();
            IgniteCache<Integer, String> cache;
            final Ignite ignite = server.getIgnite();
            CacheConfiguration<Integer, String> cacheConfig = new CacheConfiguration<>("myCache");
            cache = ignite.getOrCreateCache(cacheConfig);
            //This part of code only posts one string and retrieves the key
//           cache.put(key, value);
//           exchange.getResponseSender().send(String.format("The key for value \"%s\" is \"%s\"", cache.get(key), key));

            //This part of code puts into cache 10 different strings( one string is appended with a custom text each time)
            //and retrieves the strings and the keys corresponding to the string
        // /*
         String httpString = "ok";
            for(int i = 0; i<= 9; i++){
                 key = generateRandomSixDigitNumber();
                String valueM = String.format("%s saved with custom number %d", value,i);
                cache.put(key, valueM);
                httpString = httpString + String.format("%n %n %n  The key for value \"%s\" is \"%s\" %n", cache.get(key), key);


            }
            exchange.getResponseSender().send(httpString);
          //  */

            span.setStatus(StatusCode.OK); // Mark span as successful
        } catch (Exception e) {
            // Log the error and set span status to ERROR
            LOGGER.error("Error handling request: {}", e.getMessage(), e);
            span.setStatus(StatusCode.ERROR, "Error processing request");
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Internal server error: " + e.getMessage());
        } finally {
            // End the span
            span.end();
            exchange.endExchange();
        }
    }

    private void handleParams(final HttpServerExchange exchange) {
        final Map<String, Deque<String>> params = exchange.getQueryParameters();
        if (params == null || params.isEmpty()) {
            return;
        }

        final Deque<String> timeout = exchange.getQueryParameters().get("timeout");
        if (timeout != null && !timeout.isEmpty()) {
            timeoutS = Integer.parseInt(timeout.getFirst());
        }
    }

    public static String readFromExchange(HttpServerExchange exchange) {
        StringBuilder stringBuilder = new StringBuilder();

        // Set up a reader to read the request body
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(exchange.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (Exception e) {
            exchange.setStatusCode(500);
            exchange.getResponseSender().send("Error reading request body: " + e.getMessage());
            return null;
        }

        return stringBuilder.toString();
    }

    public static int generateRandomSixDigitNumber() {
        Random random = new Random();
        return 100000 + random.nextInt(900000); // Generates a number between 100000 and 999999
    }
}
