package com.clarifi.phoenix.ashes.util;

import com.clarifi.phoenix.ashes.common.Common;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.configuration.IgniteConfiguration;

/**
 * A class to load some sample data into Ignite caches
 */
public class LoadSampleData {

  public static void main(String[] args) throws IgniteException
  {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    // Create an IgniteCache and put some values in it.
    loadIntToStringValues(ignite, Common.SAMPLE_CACHE, 200);


    // Disconnect from the cluster.
    ignite.close();
  }

  private static void loadIntToStringValues( Ignite ignite, String cacheName, int numValues)
  {
    // Create an IgniteCache and put some values in it.
    IgniteCache<Integer, String> cache = ignite.getOrCreateCache(cacheName);

    for (int i = 0; i < numValues; ++i){
      cache.put(i, "Issue Name " + i);
    }

    System.out.println(">> Created the cache '" + cacheName + "' and added the values.");
  }

}
