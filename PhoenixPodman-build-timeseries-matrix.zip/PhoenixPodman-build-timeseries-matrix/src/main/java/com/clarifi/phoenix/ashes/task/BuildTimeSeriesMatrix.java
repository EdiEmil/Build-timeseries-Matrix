package com.clarifi.phoenix.ashes.task;

import com.clarifi.common.util.Logging;
import com.clarifi.phoenix.ashes.common.IssueDataSlicedByDataItem;
import com.clarifi.phoenix.ashes.common.PhoenixDateRange;
import com.clarifi.phoenix.ashes.common.TimeSeriesDataCache;
import com.clarifi.phoenix.ashes.data.DataItemSlicesIndex;
import com.clarifi.phoenix.ashes.data.TimeSeriesDataKey;
import com.clarifi.phoenix.ashes.data.TimeSeriesMatrix;
import org.apache.ignite.Ignite;
import org.apache.ignite.lang.IgniteCallable;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.logging.log4j.Logger;

import javax.cache.Cache;
import java.nio.ByteBuffer;
import java.util.*;

public class BuildTimeSeriesMatrix implements IgniteCallable<TimeSeriesMatrix> {
    private static final Logger LOGGER = Logging.getLogger(BuildTimeSeriesMatrix.class);

    private final int issueId;
    private final int[] dataItems;
    private final int range;

    @IgniteInstanceResource
    private Ignite ignite;

    public BuildTimeSeriesMatrix(final int issueId, final int[] dataItems, final int range) {
        this.issueId = issueId;
        this.dataItems = dataItems;
        this.range = range;
    }

    @Override
    public TimeSeriesMatrix call() throws Exception {
        final TimeSeriesMatrix.Builder builder = new TimeSeriesMatrix.Builder(issueId, range);

        for (final int dataItemId : dataItems) {
            final Cache<TimeSeriesDataKey, DataItemSlicesIndex> cache = ignite.cache(TimeSeriesDataCache.getName());
            final DataItemSlicesIndex index = cache.get(TimeSeriesDataCache.createKey(issueId, dataItemId));
            if (index == null || index.isEmpty()) {
                builder.addMissingValues(dataItemId);
            } else {
                // todo: validate issueId, dataItemId and range

                for (final IssueDataSlicedByDataItem cursor : index.getAll()) {
                    if (dataItemId == cursor.getDataItemId() && range == cursor.getDateRange()) {
                        builder.addValues(dataItemId, cursor.getValues());
                    }
                }
            }
        }

        final TimeSeriesMatrix matrix = builder.build();

        LOGGER.info(
                "{Thread:{}} built matrix for issue={}, range={} and dataItems={}. Size: {} bytes",
                Thread.currentThread().getName(),
                issueId,
                PhoenixDateRange.fromPackedValue(range),
                dataItems,
                matrix.getDataLength()
        );

        return matrix;
    }
}
