package com.clarifi.phoenix.ashes.node;

import com.clarifi.phoenix.ashes.common.Common;
import com.clarifi.phoenix.ashes.common.IssueRangeAccumulator;
import com.clarifi.phoenix.ashes.data.IssueData;
import com.clarifi.phoenix.ashes.data.SecurityMasterCache;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.Ignition;
import org.apache.ignite.cache.CachePeekMode;
import org.apache.ignite.configuration.CacheConfiguration;
import org.apache.ignite.configuration.IgniteConfiguration;
import org.apache.ignite.lang.IgniteRunnable;
import org.apache.ignite.resources.IgniteInstanceResource;

import javax.cache.Cache;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class ListLocalKeys
{
  public static void main(String[] args) throws IgniteException {
    IgniteConfiguration cfg = Common.igniteClientConfiguration();

    // Starting the node
    Ignite ignite = Ignition.start(cfg);

    System.out.println(">> Executing remote runnable task on cluster nodes.");

    // Executing custom Java compute task on server nodes.
//    ignite.compute(ignite.cluster().forServers()).broadcast(new ListLocalTimeSeriesKeysTask());

    ignite.compute(ignite.cluster().forServers()).broadcast(new IgniteRunnable() {
      @IgniteInstanceResource
      Ignite ignite;

      @Override
      public void run() {
        System.out.println(">> Executing the List Local Keys Task runnable");
        System.out.println("\tNode ID: " + ignite.cluster().localNode().id());
        IgniteCache<Integer, IssueData> cache = ignite.cache(Common.SECURITY_MASTER_CACHE);

        if (cache == null) {
          System.out.println("\tcache: " + Common.SECURITY_MASTER_CACHE + " does not exist.");
          return;
        }

        CacheConfiguration<Integer, IssueData> cfg = cache.getConfiguration(SecurityMasterCache.configuration().getClass());
        System.out.println("\tCONFIG.getCacheMode = : " + cfg.getCacheMode());

        Iterable<Cache.Entry<Integer, IssueData>> es = cache.localEntries(CachePeekMode.PRIMARY, CachePeekMode.BACKUP);
        Iterator<Cache.Entry<Integer, IssueData>> it = es.iterator();
        List<Integer> issueIds = new ArrayList<>();
        while (it.hasNext()) {
          Cache.Entry<Integer, IssueData> kv = it.next();
          int issueId = kv.getKey();
          issueIds.add(issueId);
        }
        Collections.sort(issueIds);

        IssueRangeAccumulator consolidatedIssues = new IssueRangeAccumulator();
        for (int issueId : issueIds) {
          consolidatedIssues.add(issueId);
        }

        for (int[] range : consolidatedIssues.ranges) {
          System.out.println("\t\t[" + range[0] + " .. " + range[1] + "]");
        }
        int[] range = consolidatedIssues.currentRange;
        System.out.println("\t\t[" + range[0] + " .. " + range[1] + "]");
      }
    });

    //new ListLocalSMKeysTask()
    System.out.println(">> Compute task is executed, check for output on the server nodes.");

    // Disconnect from the cluster.
    ignite.close();
  }


}
