package com.clarifi.phoenix.ashes.client;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

public class URLBuilder {
    private static final String SCHEMA_HTTP = "http";

    private String schema;
    private String userinfo;
    private String host;
    private int port;
    private String path;
    private final Map<String, String> query;

    public URLBuilder() {
        schema = SCHEMA_HTTP;
        userinfo = null;
        host = "localhost";
        port = 8080;
        path = "/";

        query = new HashMap<>();
    }

    public URLBuilder http() {
        this.schema = SCHEMA_HTTP;
        return this;
    }

    public URLBuilder host(final String value) {
        this.host = value;
        return this;
    }

    public URLBuilder port(final int value) {
        if (value < 0) {
            throw new IllegalArgumentException("Port number must be greater than 0");
        }

        this.port = value;
        return this;
    }

    public URLBuilder path(final String root, final String... children) {
        // todo: add validation

        if (children == null || children.length == 0) {
            this.path = root;
            return this;
        }

        final StringBuilder builder = new StringBuilder();
        builder.append('/');
        builder.append(root);

        for (final String child : children) {
            builder.append('/');
            builder.append(child);
        }

        this.path = builder.toString();

        return this;
    }

    public URLBuilder addQueryParameter(final String name, final String value) {
        // todo: add validation: illegal names (password, etc.), characters
        query.put(name, value);
        return this;
    }

    public URLBuilder addQueryParameters(final Map<String, String> values) {
        if (values == null || values.isEmpty()) {
            return this;
        }

        query.putAll(values);
        return this;
    }

    public URI build() {
        String queryString = null;

        if (!query.isEmpty()) {
            final StringBuilder builder = new StringBuilder();

            for (final Map.Entry<String, String> cursor : query.entrySet()) {
                builder.append(cursor.getKey());
                builder.append('=');
                builder.append(cursor.getValue());
                builder.append('&');
            }

            queryString = builder.toString();
        }

        final URI result;
        try {
            result = new URI(schema, userinfo, host, port, path, queryString, null);
        } catch (final URISyntaxException syntax) {
            // todo: log error

            syntax.printStackTrace(System.err);
            return null;
        }

        return result;
    }
}
