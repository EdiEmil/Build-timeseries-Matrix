package com.clarifi.phoenix.ashes.common;


import java.time.Instant;
import java.util.UUID;

public interface DataSession {
    UUID getId();
    UUID getUserId();
    Status getStatus();

    PhoenixDateRange getRange();
    int[] getIssues();
    int[] getDataItems();

    Instant getLastAccessedAt();
    void updateLastAccessedAt();

    enum Status {
        Initializing(0, "Initializing", "Session creation in progress"),
        Failed(2, "Failed", "Session creation failed"),
        Loading(4, "Loading", "Session created, validation/loading in progress"),
        Ready(8, "Ready", "Session created; data is valid and available");

        private final int id;
        private final String name;
        private final String description;

        Status(final int id, final String name, final String description) {
            this.id = id;
            this.name = name;
            this.description = description;
        }

        public int getId() {
            return id;
        }

        public String getName() {
            return name;
        }

        public String getDescription() {
            return description;
        }

        public String toString() {
            return this.name;
        }

        public String asString() {
            return Integer.toString(id);
        }

        public static Status fromId(final int value) {
            for (final Status candidate : values()) {
                if (candidate.id == value) {
                    return candidate;
                }
            }

            throw new IllegalArgumentException("Unsupported id value: " + value);
        }

        public static Status fromName(final String name) {
            for (final Status candidate : values()) {
                if (candidate.name.equals(name)) {
                    return candidate;
                }
            }

            throw new IllegalArgumentException("Unsupported name value: " + name);
        }
    }
}
