package com.clarifi.phoenix.ashes.data;

import org.apache.ignite.cache.affinity.AffinityKeyMapped;

public class TimeSeriesDataKey {
    @AffinityKeyMapped
    public final int issueId;
    public final int dataItemId;

    public TimeSeriesDataKey(final int issueId, final int dataItemId) {
       this.issueId = issueId;
       this.dataItemId = dataItemId;
    }

    @Override
    public int hashCode() {
        return (31 + issueId) * dataItemId;
    }

    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof TimeSeriesDataKey) {
            final TimeSeriesDataKey candidate = (TimeSeriesDataKey) obj;
            return issueId == candidate.issueId && dataItemId == candidate.dataItemId;
        }

        return false;
    }
}
