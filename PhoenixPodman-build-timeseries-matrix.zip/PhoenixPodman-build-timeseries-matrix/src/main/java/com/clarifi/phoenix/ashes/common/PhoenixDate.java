package com.clarifi.phoenix.ashes.common;

import java.lang.ref.WeakReference;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.function.Supplier;

public class PhoenixDate {
    public static PhoenixDate MIN = new PhoenixDate(Character.MIN_VALUE);
    public static PhoenixDate ANY = new PhoenixDate(Character.MAX_VALUE);
    public static PhoenixDate MAX = ANY.minusDays(1);

    private static final ThreadLocal<LocalDate> EPOCH = ThreadLocal.withInitial(new Supplier<LocalDate>() {
        @Override
        public LocalDate get() {
            return LocalDate.EPOCH;
        }
    });

    private char packed;
    private WeakReference<LocalDate> unpacked;

    public PhoenixDate(final char value) {
        this.packed = value;
    }

    public int getYear() {
        final LocalDate date = unpack();
        return date.getYear();
    }

    public int getMonth() {
        final LocalDate date = unpack();
        return date.getMonthValue();
    }

    public int getDayOfMonth() {
        final LocalDate date = unpack();
        return date.getDayOfMonth();
    }

    public char getPackedValue() {
        return packed;
    }

    /**
     * Add the specified number of days to this date.
     *
     * @param amount the number of days to add
     * @return the new date
     */
    public PhoenixDate plusDays(final int amount) {
        final char value = (char) (packed + (char) (amount & 0xFFFF));
        return PhoenixDate.fromPackedValue(value);
    }

    /**
     * Subtract the specified number of days from this date.
     *
     * @param amount the number of days to subtract
     * @return the new date
     */
    public PhoenixDate minusDays(final int amount) {
        final char value = (char) (packed - (char) (amount & 0xFFFF));
        return PhoenixDate.fromPackedValue(value);
    }

    /**
     * Checks if this PhoenixDate is equal to the specified PhoenixDate.
     *
     * This method compares the internal char values (representing the number of elapsed days since the epoch)
     * of this PhoenixDate and the specified PhoenixDate. If the values are equal, it returns true, indicating
     * that this PhoenixDate is equal to the specified PhoenixDate.
     *
     * @param obj the object to compare with
     * @return true if this PhoenixDate is equal to the specified PhoenixDate, false otherwise
     */
    @Override
    public boolean equals(final Object obj) {
        if (obj instanceof PhoenixDate) {
            final PhoenixDate candidate = (PhoenixDate) obj;
            return packed == candidate.getPackedValue();
        }

        return false;
    }

    /**
     * Checks if this PhoenixDate is before the specified PhoenixDate.
     *
     * This method compares the internal char values (representing the number of elapsed days since the epoch)
     * of this PhoenixDate and the specified PhoenixDate. If the value of this PhoenixDate is less than the
     * value of the specified PhoenixDate, it returns true, indicating that this PhoenixDate is before the
     * specified PhoenixDate.
     *
     * @param other the PhoenixDate to compare with
     * @return true if this PhoenixDate is before the specified PhoenixDate, false otherwise
     */
    public boolean isBefore(final PhoenixDate other) {
        return packed < other.packed;
    }

    public boolean isBeforeOrEqual(final PhoenixDate other) {
        return packed <= other.packed;
    }

    public boolean isAfter(final PhoenixDate other) {
        return packed > other.packed;
    }

    public boolean isAfterOrEqual(final PhoenixDate other) {
        return packed >= other.packed;
    }

    //-- There is no need to synchronize this if we go for speed vs memory efficiency;
    // it will re-compute and re-assign if called from multiple threads without side effects.
    private LocalDate unpack() {
        if (unpacked != null) {
            final LocalDate reference = unpacked.get();
            if (reference != null) {
                return reference;
            }
        }

        final LocalDate date = EPOCH.get().plusDays(packed);
        unpacked = new WeakReference<>(date);

        return date;
    }

    public static LocalDate toLocalDate(final PhoenixDate date) {
        return date.unpack();
    }

    public static PhoenixDate fromLocalDate(final LocalDate date) {
        final long daysBetween = ChronoUnit.DAYS.between(EPOCH.get(), date);

        return new PhoenixDate((char) daysBetween);
    }

    public static PhoenixDate of(final int year, final int month, final int day) {
        return fromLocalDate(LocalDate.of(year, month, day));
    }

    public static PhoenixDate fromPackedValue(final char value) {
        return new PhoenixDate(value);
    }

    @Override
    public String toString() {
        return unpack().toString();
    }
}
